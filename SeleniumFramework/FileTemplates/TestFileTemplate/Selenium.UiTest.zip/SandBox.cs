﻿using System;
using System.Threading;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SeleniumFramework.Helpers;
using SeleniumFramework.Generators;
using SeleniumFramework.Generators.GeneratorData;
using SeleniumFramework.PageClasses;
using SeleniumFramework.Helpers;


namespace $rootnamespace$
{
    [TestClass]
    public class $safeitemname$ : TestBase
    {
		//private const string TestDataFileName = "$safeitemname$";
        //private const string TestData = Config.Test_Data_Folder + TestDataFileName;
        //private const string TestDataCSV = TestDataFileName + "#csv";

        //[DataSource("Microsoft.VisualStudio.TestTools.DataSource.CSV", TestDataFileName + ".csv", TestDataCSV, DataAccessMethod.Sequential), DeploymentItem(TestData + ".csv")]

        [TestMethod]
        public void $safeitemname$Test()
        {
            //test goes here
            Pages.Workflows().LogIn(Config.UserName,Config.Password);

        }
    }
}