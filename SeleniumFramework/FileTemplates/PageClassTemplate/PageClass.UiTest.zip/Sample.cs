﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using Personify.Helpers;
using SeleniumFramework.Helpers;

namespace SeleniumFramework.PageClasses.@base
{
    class $safeitemname$ : PageBase, IPage
    {
#region Page Elements
        // Here's the element
        //[FindsBy(How = How.XPath, Using = "/html/body/div[2]/div/div[1]/div[1]/header/div/div/div[2]/a[1]")]
        
        
#endregion

#region Constructor
        public $safeitemname$(IWebDriver driver)
        {
            _driver = driver;
            PageFactory.InitElements(_driver, this);
        }
#endregion

#region Page Actions

        

        
        #endregion

        #region Helpers


        #endregion
    }
}
